from django.apps import AppConfig


class ReposConfig(AppConfig):
    name = 'repos'
